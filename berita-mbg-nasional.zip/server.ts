import express from 'express';
import cors from 'cors';
import axios from 'axios';
import * as cheerio from 'cheerio';
import path from 'path';
import { createServer as createViteServer } from 'vite';

const app = express();
app.use(cors());

app.get('/api/news', async (req, res) => {
  try {
    const { data } = await axios.get('https://www.bgn.go.id/news/berita/');
    const $ = cheerio.load(data);
    const news: any[] = [];
    
    // The news articles are wrapped in anchor tags
    $('a').each((i, el) => {
      const href = $(el).attr('href');
      const h3 = $(el).find('h3');
      
      if (h3.length > 0 && href) {
        const title = h3.text().trim();
        const img = $(el).find('img').attr('src') || '';
        
        const detailsContainer = h3.next('div.text-base');
        const publisherMatch = detailsContainer.find('p.font-semibold').text().trim();
        const paragraphs = detailsContainer.find('p');
        
        let date = '';
        if (paragraphs.length >= 3) {
          date = $(paragraphs[2]).text().trim();
        }
        
        if (date && date.length > 0) {
          let fullUrl = href;
          if (!href.startsWith('http')) {
             fullUrl = href.startsWith('/') ? `https://www.bgn.go.id${href}` : `https://www.bgn.go.id/${href}`;
          }
          news.push({
            id: i,
            title,
            url: fullUrl,
            image: img,
            publisher: publisherMatch,
            date: date
          });
        }
      }
    });
    
    res.json(news);
  } catch (error) {
    console.error("Error scraping news:", error);
    res.status(500).json({ error: 'Failed to fetch news' });
  }
});

async function startServer() {
  const PORT = 3000;

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
