import axios from 'axios';
import * as cheerio from 'cheerio';

export default async function handler(req: any, res: any) {
  // CORS Configuration for Vercel
  res.setHeader('Access-Control-Allow-Credentials', 'true')
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,PATCH,DELETE,POST,PUT')
  res.setHeader(
    'Access-Control-Allow-Headers',
    'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version'
  )

  if (req.method === 'OPTIONS') {
    res.status(200).end()
    return
  }

  try {
    const { data } = await axios.get('https://www.bgn.go.id/news/berita/');
    const $ = cheerio.load(data);
    const news: any[] = [];
    
    $('a').each((i, el) => {
      const href = $(el).attr('href');
      const h3 = $(el).find('h3');
      
      if (h3.length > 0 && href) {
        const title = h3.text().trim();
        const img = $(el).find('img').attr('src') || '';
        
        const detailsContainer = h3.next('div.text-base');
        const publisherMatch = detailsContainer.find('p.font-semibold').text().trim();
        const paragraphs = detailsContainer.find('p');
        
        let date = '';
        if (paragraphs.length >= 3) {
          date = $(paragraphs[2]).text().trim();
        }
        
        if (date && date.length > 0) {
          let fullUrl = href;
          if (!href.startsWith('http')) {
             fullUrl = href.startsWith('/') ? `https://www.bgn.go.id${href}` : `https://www.bgn.go.id/${href}`;
          }
          news.push({
            id: i,
            title,
            url: fullUrl,
            image: img,
            publisher: publisherMatch,
            date: date
          });
        }
      }
    });

    res.status(200).json(news);
  } catch (error) {
    console.error("Error scraping news:", error);
    res.status(500).json({ error: 'Failed to fetch news' });
  }
}
