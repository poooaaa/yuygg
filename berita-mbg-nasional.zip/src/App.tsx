import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { Newspaper, ExternalLink, Calendar, Link2, Search, Zap } from 'lucide-react';

interface NewsItem {
  id: number;
  title: string;
  url: string;
  image: string;
  publisher: string;
  date: string;
}

export default function App() {
  const [news, setNews] = useState<NewsItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    fetch('/api/news')
      .then(res => res.json())
      .then(data => {
        setNews(data);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  const filteredNews = news.filter(item => 
    item.title.toLowerCase().includes(search.toLowerCase()) || 
    item.publisher.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-neutral-900 text-neutral-50 font-sans selection:bg-teal-500 selection:text-white">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-neutral-900/80 backdrop-blur-xl border-b border-neutral-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="bg-teal-500/20 p-2.5 rounded-xl border border-teal-500/30">
                <Newspaper className="w-6 h-6 text-teal-400" />
              </div>
              <div>
                <h1 className="text-xl font-medium tracking-tight text-white">MBG News Portal</h1>
                <p className="text-sm font-mono text-neutral-400">Badan Gizi Nasional</p>
              </div>
            </div>
            
            <div className="relative group max-w-sm w-full md:w-auto">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-4 w-4 text-neutral-500 group-focus-within:text-teal-400 transition-colors" />
              </div>
              <input
                type="text"
                placeholder="Search articles..."
                className="w-full md:w-64 bg-neutral-800/50 border border-neutral-700 text-sm rounded-xl py-2 pl-10 pr-4 focus:outline-none focus:ring-2 focus:ring-teal-500/50 focus:border-teal-500 transition-all font-sans placeholder:text-neutral-500"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-3xl font-semibold tracking-tight">Terbaru</h2>
          {loading && (
            <div className="flex items-center gap-2 text-teal-400">
              <Zap className="w-5 h-5 animate-pulse" />
              <span className="text-sm font-medium animate-pulse">Syncing...</span>
            </div>
          )}
        </div>

        {loading ? (
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
             {[1, 2, 3, 4, 5, 6].map(i => (
               <div key={i} className="animate-pulse bg-neutral-800/50 rounded-2xl border border-neutral-800 overflow-hidden h-[400px]">
                 <div className="h-52 bg-neutral-800"></div>
                 <div className="p-6 pb-8 space-y-4">
                   <div className="h-6 bg-neutral-800 rounded w-full"></div>
                   <div className="h-6 bg-neutral-800 rounded w-4/5"></div>
                   <div className="h-4 bg-neutral-800 rounded w-1/3 mt-6"></div>
                 </div>
               </div>
             ))}
           </div>
        ) : filteredNews.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 text-center">
            <div className="w-16 h-16 bg-neutral-800 rounded-full flex items-center justify-center mb-4 border border-neutral-700">
             <Search className="w-8 h-8 text-neutral-500" />
            </div>
            <h3 className="text-lg font-medium text-neutral-200">No articles found</h3>
            <p className="text-neutral-500 mt-2">We couldn't find anything matching your search.</p>
          </div>
        ) : (
          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            initial="hidden"
            animate="visible"
            variants={{
              hidden: { opacity: 0 },
              visible: {
                opacity: 1,
                transition: {
                  staggerChildren: 0.1
                }
              }
            }}
          >
            {filteredNews.map((item) => (
              <motion.a
                key={item.id}
                href={item.url.startsWith('http') ? item.url : `https://www.bgn.go.id${item.url}`}
                target="_blank"
                rel="noopener noreferrer"
                className="group flex flex-col bg-neutral-900 border border-neutral-800 rounded-2xl overflow-hidden hover:border-teal-500/50 transition-all duration-300 hover:shadow-[0_8px_30px_rgb(20,184,166,0.1)] focus:outline-none focus:ring-2 focus:ring-teal-500 focus:ring-offset-2 focus:ring-offset-neutral-900"
                variants={{
                  hidden: { y: 20, opacity: 0 },
                  visible: { y: 0, opacity: 1, transition: { type: "spring", stiffness: 300, damping: 24 } }
                }}
                whileHover={{ y: -4 }}
              >
                <div className="relative aspect-[16/10] overflow-hidden bg-neutral-800">
                  <div className="absolute inset-0 bg-neutral-800 animate-pulse" />
                  <img 
                    src={item.image || 'https://images.unsplash.com/photo-1504711434969-e33886168f5c?auto=format&fit=crop&q=80'} 
                    alt={item.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 relative z-10"
                    onLoad={(e) => {
                      (e.target as HTMLImageElement).previousElementSibling?.remove();
                    }}
                    onError={(e) => {
                       (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1504711434969-e33886168f5c?auto=format&fit=crop&q=80';
                    }}
                  />
                  <div className="absolute top-4 right-4 z-20 opacity-0 group-hover:opacity-100 transition-opacity bg-neutral-900/80 backdrop-blur-sm p-2 rounded-full border border-neutral-700">
                    <ExternalLink className="w-4 h-4 text-white" />
                  </div>
                </div>
                
                <div className="flex flex-col flex-grow p-6">
                  <h3 className="text-xl font-medium text-neutral-100 mb-4 line-clamp-3 leading-snug group-hover:text-teal-400 transition-colors">
                    {item.title}
                  </h3>
                  
                  <div className="mt-auto flex items-center justify-between text-xs font-mono text-neutral-400 border-t border-neutral-800 pt-4">
                    <div className="flex items-center gap-1.5 truncate pr-4">
                      <Link2 className="w-3.5 h-3.5 shrink-0" />
                      <span className="truncate">{item.publisher || 'BGN'}</span>
                    </div>
                    {item.date && (
                      <div className="flex items-center gap-1.5 shrink-0">
                        <Calendar className="w-3.5 h-3.5" />
                        <span>{item.date}</span>
                      </div>
                    )}
                  </div>
                </div>
              </motion.a>
            ))}
          </motion.div>
        )}
      </main>
    </div>
  );
}
